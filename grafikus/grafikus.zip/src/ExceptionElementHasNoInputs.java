
public class ExceptionElementHasNoInputs extends ExceptionsWithConnection{
	public DigitalObject TheObject;

	ExceptionElementHasNoInputs(DigitalObject obj) {
		TheObject = obj;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = -448300044651553318L;

}


public class ExceptionWireHasMultipleInputs extends ExceptionsWithConnection {
	
	public Wire TheObject;
	ExceptionWireHasMultipleInputs(Wire obj){
		TheObject = obj;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = -9074820954687001213L;

}

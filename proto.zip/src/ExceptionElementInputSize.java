public class ExceptionElementInputSize extends ExceptionsWithConnection {
	public DigitalObject TheObject;

	ExceptionElementInputSize(DigitalObject obj) {
		TheObject = obj;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -4031552574320794411L;

}

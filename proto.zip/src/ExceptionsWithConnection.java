
public class ExceptionsWithConnection extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2168292329984866711L;

}


public class ExceptionElementNotConnected extends ExceptionsWithConnection{
	public DigitalObject TheObject;
	ExceptionElementNotConnected(DigitalObject obj){
		TheObject = obj;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = -6637876449881535299L;

}

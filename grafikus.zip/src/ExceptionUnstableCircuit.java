
public class ExceptionUnstableCircuit extends Exception{
	public DigitalObject TheObject;
	ExceptionUnstableCircuit(DigitalObject obj){
		TheObject = obj;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 529347985460608015L;

}

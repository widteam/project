/*
* Nev: 			Output
* Tipus: 		Class
* Interfacek:	iComponent
* Szulok		DigitalObject
*  
*********** Leiras **********
* A bemenet megjelenitesere szolgalo objektum/osztaly

*/
public abstract class Output extends DigitalObject{
	/*  ATTRIBUTUMOK  */
	protected int Value;
	// Leiras: Az adott Output objektum erteket tarolja
	
	
	/*	METODUSOK	*/
}

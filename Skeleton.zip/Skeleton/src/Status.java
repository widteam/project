/*
* Nev: 			Status
* Tipus: 		Enum
* Interfacek:	---
* Szulok		---
*  
*********** Leiras **********
* A program futasi allapotai

*/

public enum Status {
	RUNNING,STOPPED,PAUSED
}

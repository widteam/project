import java.io.*;
public class main {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		char TesterChoice = 0;
		
		InputStreamReader in  = new InputStreamReader(System.in);
		OutputStreamWriter out = new OutputStreamWriter(System.out);
		
		// DigitalBoard l�trehoz�sa
		DigitalBoard o = new DigitalBoard();
		


		try {
			while(TesterChoice == 0){
				System.out.println("TESZT SZAKASZ");
				System.out.println("K�rem v�lasszon a lehet�s�gek k�z�l!");
				System.out.println("  0 - Load Board (Egyszer�) ");
				System.out.println("  1 - Load Board (Visszacsatol�ssal) ");
				System.out.println("  3 - Load Board (Instabil) ");
				System.out.println("  4 - Toggle Switch");
				System.out.println("  5 - Set Sequence");
				System.out.println("  6 - Step Components");
				System.out.println("  7 - Step");
				System.out.println("  8 - Count");
				System.out.println("  9 - Check Value");
				
				
				
				TesterChoice =  (char) in.read();				
				System.out.println(TesterChoice);
				
				switch (TesterChoice){
				case '0':					
					o.LoadBoard("0");
					
					break;
				case '1':
					o.LoadBoard("1");
					break;
				case '2':
					o.LoadBoard("2");
					break;
				case '3':
					break;
				case '4':
					break;
				case '5':
					break;	
				case '6':
					break;					
				default:
					TesterChoice = 0;
				}
				

					
			}
		} catch (Exception e) {			
			e.printStackTrace();
		}
	}

}

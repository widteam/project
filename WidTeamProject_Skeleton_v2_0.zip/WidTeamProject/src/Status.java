/*
* N�v: 			Status
* T�pus: 		Enum
* Interfacek:	---
* Sz�l�k		---
*  
*********** Le�r�s **********
* A program fut�si �llapotai

*/

public enum Status {
	RUNNING,STOPPED,PAUSED
}
